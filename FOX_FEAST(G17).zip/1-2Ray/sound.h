#pragma once
#include "raylib.h"

extern Music bgMusic;
extern Sound clickSound;
extern Sound duckKillSound;
extern Sound gameOverSound;
extern Sound gameWinSound;

void InitSounds();
void UpdateMusic();
void CloseSounds();

