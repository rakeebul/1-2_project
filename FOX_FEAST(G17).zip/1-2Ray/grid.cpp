#include "score.h"
#include "game.h"
#include "grid.h"

Color  lightGreen ={102, 205, 102, 255};
Color darkGreen = {92, 205, 92, 255};
Color brown = {139,69,19,255};

bool IsObstacle(int currentLevel, int x, int y) {
    switch(currentLevel){
        bool condition;
        case 1:
            condition = (x==4 && y>=topBarHeight+3 && y<=topBarHeight+15)
                    || (x==4 && y>=topBarHeight+22 && y<=topBarHeight+29)
                    || (x==9 && y>=topBarHeight+1 && y<=topBarHeight+9)
                    || (x==23 && y>=topBarHeight+14 && y<=topBarHeight+26)
                    || (y==topBarHeight+5 && x>=13 && x<=19)
                    || (y==topBarHeight+19 && x>=7 && x<=21)
                    || (y==topBarHeight+2 && x>=6 && x<=17)
                    || (x == 8  && y >= topBarHeight + 12 && y <= topBarHeight + 18)
                     || (x == 14 && y >= topBarHeight + 21 && y <= topBarHeight + 26)
                     || (x == 26 && y >= topBarHeight + 4  && y <= topBarHeight + 10)
                     || (y == topBarHeight + 8  && x >= 11 && x <= 16)
                     || (y == topBarHeight + 23 && x >= 20 && x <= 27)
                     || (y == topBarHeight + 27 && x >= 3  && x <= 10)
                     || (x==20 && y>=topBarHeight+5 && y<=topBarHeight+12);
            return condition;
            break;
        case 2:
            condition = (x==4 && y>=topBarHeight+2 && y<=topBarHeight+15)
                    || (x == 2  && y >= topBarHeight + 5  && y <= topBarHeight + 20)
                    || (x == 10 && y >= topBarHeight + 6  && y <= topBarHeight + 25)
                    || (x == 19 && y >= topBarHeight + 2  && y <= topBarHeight + 12)
                    || (x == 22 && y >= topBarHeight + 10 && y <= topBarHeight + 29)
                    || (x == 29 && y >= topBarHeight + 9 && y <= topBarHeight + 18)
                    || (y == topBarHeight + 5  && x >= 7  && x <= 14)
                    || (y == topBarHeight + 12 && x >= 12 && x <= 20)
                    || (y == topBarHeight + 19 && x >= 3  && x <= 18)
                    || (y == topBarHeight + 27 && x >= 17 && x <= 28)
                    || (y == topBarHeight + 25 && x >= 4 && x <= 9)
                    || (y == topBarHeight + 6 && x >= 24 && x <= 30);
            return condition;
            break;
        case 3:
            condition =(x == 4  && y >= topBarHeight + 1  && y <= topBarHeight + 28 && y != topBarHeight + 10)
                || (x == 8  && y >= topBarHeight + 7  && y <= topBarHeight + 29 && y != topBarHeight + 16)
                || (x == 12 && y >= topBarHeight + 13  && y <= topBarHeight + 27 && y != topBarHeight + 22)
                || (x == 23 && y >= topBarHeight + 15  && y <= topBarHeight + 28 && y != topBarHeight + 20)
                || (x == 27 && y >= topBarHeight + 24  && y <= topBarHeight + 29 && y != topBarHeight + 12)
                || (x == 29 && y >= topBarHeight + 3 && y <= topBarHeight + 16 )
                || (x == 16 && y >= topBarHeight + 18 && y <= topBarHeight + 26 )
                || (y == topBarHeight + 4  && x >= 5  && x <= 12 && x != 18)
                || (y == topBarHeight + 10 && x >= 11 && x <= 19 && x != 14)
                || (y == topBarHeight + 6 && x >= 8  && x <= 24 && x != 30)
                || (y == topBarHeight + 22 && x >= 17 && x <= 21 && x != 19)
                || (y == topBarHeight + 8 && x >= 16 && x <= 4 && x != 12)
                || (y == topBarHeight + 13 && x >= 23 && x <= 29 && x != 29)
                || (y == topBarHeight + 12 && x >= 17 && x <= 21 && x != 29)
                || (y == topBarHeight + 29 && x >= 15 && x <= 25 && x != 29);
            return condition;
            break;
    }
}

void DrawGrid(int currentLevel) {
    switch(currentLevel){
        case 1:
            for(int i=0;i<GRID_SIZE;i++){
                for(int j=0+topBarHeight;j<GRID_SIZE+topBarHeight;j++){
                    Color color = IsObstacle(currentLevel,i,j)? brown : ((i+j)%2==0?lightGreen:darkGreen);
                    DrawRectangle(i*TILE_SIZE,j*TILE_SIZE,TILE_SIZE,TILE_SIZE,color);
                }
            }
        case 2:
            for(int i=0;i<GRID_SIZE;i++){
                for(int j=0+topBarHeight;j<GRID_SIZE+topBarHeight;j++){
                    Color color = IsObstacle(currentLevel,i,j)? brown : ((i+j)%2==0?lightGreen:darkGreen);
                    DrawRectangle(i*TILE_SIZE,j*TILE_SIZE,TILE_SIZE,TILE_SIZE,color);
                }
            }
        case 3:
            for(int i=0;i<GRID_SIZE;i++){
                for(int j=0+topBarHeight;j<GRID_SIZE+topBarHeight;j++){
                    Color color = IsObstacle(currentLevel,i,j)? brown : ((i+j)%2==0?lightGreen:darkGreen);
                    DrawRectangle(i*TILE_SIZE,j*TILE_SIZE,TILE_SIZE,TILE_SIZE,color);
                }
            }
    }
}
