#include "UI_func.h"
#include "raygui.h"
#include "raylib.h"
#include "game.h"
#include "ducks.h"
#include "score.h"
#include "save_state.h"
#include<bits/stdc++.h>
#define ROUNDNESS 1

Texture2D menuBG;
Font roundedFont;
Texture2D iconSoundOn;
Texture2D iconSoundOff;
Texture2D leaderboardBG;

void LoadMenuAssets() {
    menuBG = LoadTexture("asset/menu_background.png");
    roundedFont = LoadFont("asset/Quicksand-Regular.ttf");
    iconSoundOn = LoadTexture("asset/volume.png");
    iconSoundOff = LoadTexture("asset/mute.png");
    lifeIcon = LoadTexture("asset/life.png");
    leaderboardBG = LoadTexture("asset/BG.jpg");
}

void UnloadMenuAssets() {
    UnloadTexture(menuBG);
    UnloadFont(roundedFont);
    UnloadTexture(iconSoundOn);
    UnloadTexture(iconSoundOff);
    UnloadTexture(lifeIcon);
    UnloadTexture(leaderboardBG);

}

bool IsMouseOver(Rectangle rect) {
    return CheckCollisionPointRec(GetMousePosition(), rect);
}

bool DrawPillButton(Rectangle rect, const char *text, Color baseColor, Color hoverColor, Color textColor, float roundness, Font font) {
    bool hovered = IsMouseOver(rect);
    DrawRectangleRounded(rect, roundness, 16, hovered ? hoverColor : baseColor);

    Vector2 textSize = MeasureTextEx(font, text, 20, 1);
    Vector2 textPos = {
        rect.x + (rect.width - textSize.x) / 2,
        rect.y + (rect.height - textSize.y) / 2
    };

    DrawTextEx(font, text, textPos, 20, 1, textColor);
    return hovered && IsMouseButtonPressed(MOUSE_LEFT_BUTTON);
}

bool DrawBackToMenuButton() {
    Rectangle menuRect = { 10, 20, 80, 30 };
    return DrawPillButton(menuRect, "Menu", DARKGRAY, GRAY, YELLOW, 0.5f, roundedFont);
}

void showMenuFromGame(){
    int btnW = 250, btnH = 60, spacing = 20;
    int totalH = (btnH + spacing) * 5 - spacing;
    int startY = (GetScreenHeight() - totalH) / 2;
    int centerX = (GetScreenWidth() - btnW) / 2;
    int x = GetScreenWidth() / 2 - 75;
    int y = GetScreenHeight() / 2 - 100;

    ClearBackground(RAYWHITE);
    DrawTexture(menuBG, 0, 0, WHITE);
    const char *labels[] = { "Resume", "New Game", "Sound: %s", "Leaderboard", "Exit" };

    for (int i = 0; i < 4; i++) {
        Rectangle btn = { (float)centerX, (float)(startY + i * (btnH + spacing)), (float)btnW, (float)btnH };
        char label[64];

        if (i == 2) sprintf(label, labels[i], soundEnabled ? "On" : "Off");
        else strcpy(label, labels[i]);

        if (DrawPillButton(btn, label, BLUE, DARKBLUE, WHITE, 1.0f, roundedFont)) {
            switch (i) {
                case 0:{
                        wolfX = savedWolfX;
                        wolfY = savedWolfY;
                        lastDirection = savedLastDirection;
                        gameTimeRemaining = savedGameTimeRemaining;
                        gameOver = savedGameOver;
                        memcpy(ducks, savedDucks, sizeof(ducks));

                        gameState = GAME;
                        gameInitialized = true;
                        resumeRequested = false;
                        break;
                }
                case 1: {
                        memset(tempPlayerName, 0, sizeof(tempPlayerName));
                        wolfX = 0;
                        wolfY = topBarHeight;
                        lastDirection = DOWN;
                        duckKillCount = 0;
                        wolfLives = MAX_WOLF_LIVES;
                        gameTimeRemaining = 120.0f;
                        gameOver = false;
                        //memcpy(ducks, savedDucks, sizeof(ducks));
                        InitDucks(ducks, NUM_DUCKS);
                        gameState = GAME;
                        gameInitialized = true;  // Already initialized before, just resume
                        resumeRequested = false;
                        waitingForNameInput = true;
                        break;
                }

                case 2: soundEnabled = !soundEnabled; break;
                case 3: gameState = LEADERBOARD; break;
                case 4: gameState = EXITING; break;
            }
        }
    }
    return;
}

void showMenu() {
    int btnW = 250, btnH = 60, spacing = 20;
    int totalH = (btnH + spacing) * 5 - spacing;
    int startY = (GetScreenHeight() - totalH) / 2;
    int centerX = (GetScreenWidth() - btnW) / 2;
    int x = GetScreenWidth() / 2 - 75;
    int y = GetScreenHeight() / 2 - 100;

    ClearBackground(RAYWHITE);

    if (gameState == MENU && previousGameState == GAME && !resumeRequested) {
        if (levelCompletedFlag) {
            DrawTexture(leaderboardBG, 0, 0, WHITE);
            DrawTextEx(roundedFont, TextFormat("Level Completed!"),
               (Vector2){220 , 150}, 50, 0.8f, GREEN);
           Rectangle playAgainBtn = { 300, 350, 150, 40 }; // same as old button
        if (DrawPillButton(playAgainBtn, "Play Again", DARKBLUE, BLUE, WHITE, 0.8f, roundedFont)) {
                gameState = GAME;
                gameInitialized = false;
                levelCompletedFlag = false;
                gameOver = false;
        }
        if (currentLevel < maxLevels) {
            Rectangle playAgainRect = { 300, 450, 150, 40 };

            if (DrawPillButton(playAgainRect, "Next Level", DARKBLUE, BLUE, WHITE, 0.8f, roundedFont)) {
                    currentLevel++;
                    gameState = GAME;
                    gameInitialized = false;
                    levelCompletedFlag = false;
                    gameOver = false;
            }
        }
        else {
            DrawTexture(leaderboardBG, 0, 0, WHITE);
            DrawText("All Levels Completed!", x - 30, y + 120, 20, DARKGREEN);
        }
        return;
    }
    else if (levelFailed) {
            DrawTexture(leaderboardBG, 0, 0, WHITE);
            DrawTextEx(roundedFont, TextFormat("Level Failed!"),
               (Vector2){300 , 250}, 50, 0.8f, GREEN);
            if (GuiButton((Rectangle){ x, y, 150, 40 }, "Play Again")) {
                wolfLives = MAX_WOLF_LIVES;
                wolfX = 0;
                wolfY = topBarHeight;
                moveTimer = 0;
                duckMoveTimer = 0;
                gameTimeRemaining = 120.0f;
                gameOver = false;
                levelFailed = false;
                currentLevelScore = 0;
                InitDucks(ducks, NUM_DUCKS);
                LoadLevel(currentLevel); // <== make sure this is declared

                gameState = GAME;
            }
            return;
        }
    }
    if (waitingForNameInput) {
        DrawRectangle(0, 0, GetScreenWidth(), GetScreenHeight(), Fade(BLACK, 0.6f));
        DrawTextEx(roundedFont,"Enter Your Name",
                (Vector2){ (float)(GetScreenWidth() / 2 - 70), (float)(GetScreenHeight() / 2 - 60) }, 20, 1.0f, WHITE);

        GuiTextBox((Rectangle){ (float)(GetScreenWidth() / 2 - 100), (float)(GetScreenHeight() / 2 - 30), 200.0f, 40.0f }, tempPlayerName, 32, true);
        Rectangle startBtn = {
            (float)(GetScreenWidth() / 2 - 40),
            (float)(GetScreenHeight() / 2 + 30),
            80.0f, 45.0f
        };

    if (DrawPillButton(startBtn, "Start", BLUE, DARKBLUE, WHITE, 1.0f, roundedFont)) {
    strcpy(playerName, tempPlayerName);
                nameEntered = true;
                waitingForNameInput = false;
                gameState = GAME;
                gameInitialized = false;
                currentLevel = 1;
                cumulativeScore = 0;}
            return;
    }
    DrawTexture(menuBG, 0, 0, WHITE);
    const char *labels[] = { "Resume", "New Game", "Sound: %s", "Leaderboard", "Exit" };

    for (int i = 1; i < 5; i++) {
        Rectangle btn = { (float)centerX, (float)(startY + i * (btnH + spacing)), (float)btnW, (float)btnH };
        char label[64];
        if (i == 2)
            sprintf(label, labels[i], soundEnabled ? "On" : "Off");
        else
            strcpy(label, labels[i]);

        if (DrawPillButton(btn, label, BLUE, DARKBLUE, WHITE, 1.0f, roundedFont)) {
            switch (i) {
                case 0: // Resume
                    resumeRequested = true;
                    gameState = GAME;
                    gameInitialized = false;
                    break;

                case 1: // New Game
                    memset(tempPlayerName, 0, sizeof(tempPlayerName));
                    waitingForNameInput = true;
                    break;

                case 2: // Toggle sound
                    soundEnabled = !soundEnabled;
                    break;

                case 3: // Leaderboard
                    gameState = LEADERBOARD;
                    break;

                case 4: // Exit
                    gameState = EXITING;
                    break;
            }
        }
    }
}

void DrawUIBar(int timeRemaining, int duckKillCount, int highScore, bool *pausedFlag) {
    DrawRectangle(0, 0, GetScreenWidth(), TILE_SIZE + 50, DARKGRAY);

    if (DrawBackToMenuButton()) {
        previousGameState = GAME;
        //gameState = MENU;
        gameState = MENUfromGame;
        resumeRequested = true;
    }

    int fontSize = 24;
    DrawTextEx(roundedFont, TextFormat("Player: %s", playerName),
               (Vector2){130, 22}, fontSize, 1, WHITE);

    // Draw time
    DrawTextEx(roundedFont, TextFormat("Time: %02d:%02d", timeRemaining / 60, timeRemaining % 60),
               (Vector2){250 + 40, 22}, fontSize, 1, WHITE);

    // Draw score
    int score = 0;
    score=duckKillCount;
    DrawTextEx(roundedFont, TextFormat("Score: %d", score),
               (Vector2){375 + 40, 22}, fontSize, 1, WHITE);

    Rectangle pauseBtn = {(float)(GetScreenWidth() - 140), 20, 120, 36};

    const char *pauseText = *pausedFlag ? "Resume" : "Pause";

    if (DrawPillButton(pauseBtn, pauseText, DARKGRAY, GRAY, YELLOW, 0.5f, roundedFont)) {
        *pausedFlag = !(*pausedFlag);  // Toggle pause state
    }

    // --- Sound button ---
    int btnSize = 36;
    Rectangle circleBtn = { GetScreenWidth() / 2 + 75 + 40, 15, (float)btnSize, (float)btnSize };
    Color baseColor = DARKBLUE;
    Color hoverColor = BLUE;
    bool hovered = CheckCollisionPointRec(GetMousePosition(), circleBtn);
    Color fillColor = hovered ? hoverColor : baseColor;
    DrawRectangleRounded(circleBtn, 1.0f, 16, fillColor);

    Texture2D icon = soundEnabled ? iconSoundOn : iconSoundOff;
    DrawTexturePro(icon,
        (Rectangle){ 0, 0, (float)icon.width, (float)icon.height },
        (Rectangle){ circleBtn.x + 4, circleBtn.y + 4, btnSize - 8, btnSize - 8 },
        (Vector2){ 0, 0 }, 0.0f, WHITE);

    if (hovered && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
        soundEnabled = !soundEnabled;
    }

    int wolfLivesX = 563;
    int wolfLivesY = 25;

    int displayLives = (wolfLives < 0) ? 0 : wolfLives;

    // Draw the lives count as text
    DrawTextEx(roundedFont, TextFormat("%d", displayLives),
               (Vector2){wolfLivesX + 40, wolfLivesY}, fontSize, 1, WHITE);

    // Draw the life icon next to the count
    Vector2 iconPos = { 520 + 40, wolfLivesY - 10 };
    float iconScale = 0.08f;
    DrawTextureEx(lifeIcon, iconPos, 0.0f, iconScale, WHITE);

    Rectangle playAgainBtn = {(float)(GetScreenWidth()/2-25), 290, 60, 36};
    if (levelFailed && DrawPillButton(playAgainBtn, "PLAY AGAIN", DARKGRAY, GRAY, YELLOW, 0.5f, roundedFont) ) {
        gameState = GAME;
        resumeRequested = false;
        gameInitialized = false;
        levelFailed = false;
        gameOver = false;

        // Reset wolfLives and position
        wolfLives = MAX_WOLF_LIVES;
        wolfX = 0;
        wolfY = topBarHeight;
        lastDirection = DOWN;

        // Reset ducks, timer, etc.
        InitDucks(ducks, NUM_DUCKS);
        gameTimeRemaining = 120.0f;
        moveTimer = 0.0f;
        duckMoveTimer = 0;

        // Force reload of level assets (optional but safe)
        RunGameUnload();
        LoadLevel(currentLevel);
    }


}
