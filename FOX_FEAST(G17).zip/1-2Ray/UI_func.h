// ui.h
#ifndef UI_func_H
#define UI_func_H

#include "raylib.h"

extern Texture2D menuBG;
extern Font menuFont;
extern bool soundEnabled;

void LoadMenuAssets();
void UnloadMenuAssets();
void showMenu();
bool DrawPillButton(Rectangle bounds, const char *text, Color normalColor, Color hoverColor, Color textColor, float fontSize, Font roundedFont);
void DrawUIBar(int timeRemaining, int duckKillCount, int highScore, bool *pausedFlag);
bool DrawBackToMenuButton();
void GameEndMsg();
void showMenuFromGame();

#endif


