#ifndef WOLF_H
#define WOLF_H

#include "raylib.h"
#include "game.h"

void LoadWolfTextures(Texture2D wolfTex[4]);
void UnloadWolfTextures(Texture2D wolfTex[4]);

void MoveWolf(int *x, int *y, float *moveTimer, float moveInterval, Direction *lastDirection);

void DrawWolf(Texture2D wolfTex[4], int x, int y, Direction lastDirection);

bool IsWalkable(int x, int y, int *lastDirection);
#endif
