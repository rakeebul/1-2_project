#include "game.h"
#include <cstdio>
#include <cstring>

const char *SAVE_FILE = "save.dat"; // use .dat for binary

bool SaveGameStateToFile() {
    FILE *file = fopen(SAVE_FILE, "wb"); // binary write
    if (!file) return false;

    fwrite(&wolfX, sizeof(int), 1, file);
    fwrite(&wolfY, sizeof(int), 1, file);
    int dirInt = (int)lastDirection;
    fwrite(&dirInt, sizeof(int), 1, file);
    fwrite(&gameTimeRemaining, sizeof(float), 1, file);
    fwrite(&duckKillCount, sizeof(int), 1, file);

    // Save gameOver as false always to allow resume
    bool validGameOver = false;
    fwrite(&validGameOver, sizeof(bool), 1, file);

    fwrite(&wolfLives, sizeof(int), 1, file);
    fwrite(ducks, sizeof(Duck), NUM_DUCKS, file); // save all ducks
    fwrite(playerName, sizeof(char), sizeof(playerName), file);
    fwrite(&currentLevel, sizeof(int), 1, file);
    fwrite(&cumulativeScore, sizeof(int), 1, file);

    fclose(file);
    return true;
}

bool LoadGameStateFromFile() {
    FILE *file = fopen(SAVE_FILE, "rb"); // binary read
    if (!file) return false;

    if (fread(&wolfX, sizeof(int), 1, file) != 1) { fclose(file); return false; }
    if (fread(&wolfY, sizeof(int), 1, file) != 1) { fclose(file); return false; }

    int dirInt;
    if (fread(&dirInt, sizeof(int), 1, file) != 1) { fclose(file); return false; }
    lastDirection = (Direction)dirInt;

    if (fread(&gameTimeRemaining, sizeof(float), 1, file) != 1) { fclose(file); return false; }
    if (fread(&duckKillCount, sizeof(int), 1, file) != 1) { fclose(file); return false; }

    if (fread(&gameOver, sizeof(bool), 1, file) != 1) { fclose(file); return false; }

    if (fread(&wolfLives, sizeof(int), 1, file) != 1) { fclose(file); return false; }
    if (fread(ducks, sizeof(Duck), NUM_DUCKS, file) != NUM_DUCKS) { fclose(file); return false; }
    if (fread(playerName, sizeof(char), sizeof(playerName), file) != sizeof(playerName)) { fclose(file); return false; }
    if (fread(&currentLevel, sizeof(int), 1, file) != 1) { fclose(file); return false; }
    if (fread(&cumulativeScore, sizeof(int), 1, file) != 1) { fclose(file); return false; }

    fclose(file);
    return true;
}

bool GameSaveExists() {
    FILE *file = fopen(SAVE_FILE, "rb");
    if (!file) return false;
    fclose(file);
    return true;
}

