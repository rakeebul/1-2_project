#ifndef SAVE_STATE_H
#define SAVE_STATE_H

void SaveGameState();
bool LoadGameState();
bool GameSaveExists();
#endif
