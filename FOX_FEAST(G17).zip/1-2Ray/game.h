#ifndef GAME_H
#define GAME_H
#include "raylib.h"

#define MOVE_SWITCH_INTERVAL 200  // frames per movement pattern

const int GRID_SIZE = 32;
const int TILE_SIZE = 25;
const int topBarHeight = 3;
const int NUM_DUCKS=10;
extern bool gamePaused;
extern bool soundEnabled;
extern int wolfX;
extern int wolfY;

enum GameState { MENU, OLDGAME, MENUfromGame, GAME, LEADERBOARD, EXITING };

extern int savedWolfX, savedWolfY;
extern int savedDuckKillCount;
extern float savedGameTimeRemaining;
extern bool savedGameOver;

extern float moveTimer;
extern float duckMoveTimer;

extern GameState gameState;
extern GameState previousGameState;
extern bool resumeRequested;
extern bool gameInitialized;

extern int wolfLives;
extern int MAX_WOLF_LIVES;
extern int timeRemaining;
extern int duckKillCount;
extern char playerName[12];


extern float gameTimeRemaining;
extern bool gameOver;
extern Texture2D lifeIcon;
extern Texture2D leaderboardBG;


extern char playerName[12];
extern int currentLevel;
extern bool waitingForNameInput;
extern bool nameEntered;
extern char tempPlayerName[12];

extern const int maxLevels;

extern int currentLevelScore;     // Score of the current level
extern int cumulativeScore;       // Total score across levels

// Level completion flags
extern bool levelCompletedFlag;           // True if level (success or fail) ends
extern bool levelCompletedSuccessfully;   // True if level was completed successfully
extern bool levelFailed;                  // True if player failed the level

extern Music bgMusic;  // it failed

typedef enum {
    UP = 0,
    DOWN,
    LEFT,
    RIGHT
} Direction;
extern GameState gameState;
extern Direction lastDirection;

struct Duck {
    int x, y;
    bool active;
};
extern Direction savedLastDirection;
extern Duck savedDucks[NUM_DUCKS];
extern Duck ducks[NUM_DUCKS];
extern int savedWolfLives;
extern int savedDuckKillCount;
extern bool showLevelResultScreen;

void DrawGrid();

int RunGame();

void LoadLevel(int currentLevel);


void HandleWolfInput(int &wolfGridX, int &wolfGridY);
void SmoothWolfMovement(float &wolfPosX, float &wolfPosY, int wolfGridX, int wolfGridY, float dt);
void DrawWolf(Texture2D wolfTex, float wolfPosX, float wolfPosY);

void InitDucks(Duck ducks[], int numDucks);
void MoveDucks(Duck ducks[], int numDucks);
void CheckWolfDuckCollision(Duck ducks[], int numDucks, int wolfX, int wolfY);
void DrawDucks(Duck ducks[], int numDucks, Texture2D duckTex);

void RunGameInit();
void RunGameUpdate();
void RunGameDraw();
void RunGameUnload() ;

#endif


