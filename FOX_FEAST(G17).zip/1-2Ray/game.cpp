#include "raylib.h"
#include "game.h"
#include "UI_func.h"
#include "wolf.h"
#include "ducks.h"
#include "grid.h"
#include "score.h"
#include <stdlib.h>
#include <string.h>

#define NUM_DUCKS 10

bool soundEnabled = true;
bool gamePaused = false;
bool gameOver = false;

GameState gameState = MENU;
GameState previousGameState = MENU;
bool resumeRequested = false;
bool gameInitialized = false;

int wolfLives = 3;
int MAX_WOLF_LIVES = 3;
int timeRemaining = 120;
int duckKillCount = 0;
char playerName[12] = "";

const int maxLevels = 3;
int cumulativeScore = 0;

char tempPlayerName[12] = "";
bool waitingForNameInput = false;
bool nameEntered = false;

int wolfX = 0, wolfY = topBarHeight;
int initialWolfX = 0, initialWolfY = topBarHeight;
Direction lastDirection = DOWN;
Duck ducks[NUM_DUCKS];
float gameTimeRemaining = 120.0f;
float moveInterval = 0.2f;

int highScore = 0;
float moveTimer = 0.0f, duckMoveTimer = 0.0f;

static Texture2D wolfTex[4];
static Texture2D duckTex;
static Sound duckHitSound;

int savedWolfX = 0, savedWolfY = 0;
Direction savedLastDirection = DOWN;
float savedGameTimeRemaining = 120.0f;
bool savedGameOver = false;
Duck savedDucks[NUM_DUCKS];
int savedWolfLives = wolfLives;
int savedDuckKillCount = 0;

int currentLevel = 1;
bool showLevelResultScreen = false;

int currentLevelScore = 0;

bool levelCompletedFlag = false;
bool levelCompletedSuccessfully = false;
bool levelFailed = false;

Texture2D lifeIcon;

void LoadLevel(int currentLevel) {
    DrawGrid(currentLevel);
    switch(currentLevel){
        case 1:{
            wolfTex[UP] = LoadTexture("asset/wolf_lvl1_UP_final.png");
            wolfTex[DOWN] = LoadTexture("asset/wolf_lvl1_DOWN_final.png");
            wolfTex[LEFT] = LoadTexture("asset/wolf_lvl1_LEFT_final.png");
            wolfTex[RIGHT] = LoadTexture("asset/wolf_lvl1_RIGHT.png");
            break;
}

        case 2:{
            wolfTex[UP] = LoadTexture("asset/wolf_lvl2_up.png");
            wolfTex[DOWN] = LoadTexture("asset/wolf_lvl2_down.png");
            wolfTex[LEFT] = LoadTexture("asset/wolf_lvl2_left.png");
            wolfTex[RIGHT] = LoadTexture("asset/wolf_lvl2_right.png");
            break;
        }

        case 3:{
            wolfTex[UP] = LoadTexture("asset/wolf_lvl3_UP_final.png");
            wolfTex[DOWN] = LoadTexture("asset/wolf_lvl3_DOWN_final.png");
            wolfTex[LEFT] = LoadTexture("asset/wolf_lvl3_LEFT_final.png");
            wolfTex[RIGHT] = LoadTexture("asset/wolf_lvl3_RIGHT_final.png");
            break;
        }
    }
}

void RunGameInit() {
    LoadLevel(currentLevel);
    duckTex = LoadTexture("asset/duck_.png");
    duckHitSound = LoadSound("asset/kill_sound.mp3");

    if (gameState == GAME && !resumeRequested) {
        wolfX = initialWolfX;
        wolfY = initialWolfY;
        lastDirection = DOWN;
        gameTimeRemaining = 120.0f;
        moveTimer = 0.0f;
        duckMoveTimer = 0.0f;
        gameOver = false;
        InitDucks(ducks, NUM_DUCKS);
    }

    highScore = LoadHighScore("highscore.txt");
}

void RunGameUpdate() {
    if (gameState == OLDGAME && !gameInitialized) {
        wolfX = savedWolfX;
        wolfY = savedWolfY;
        lastDirection = savedLastDirection;
        gameTimeRemaining = savedGameTimeRemaining;
        gameOver = savedGameOver;
        memcpy(ducks, savedDucks, sizeof(ducks));
        gameState = GAME;
        gameInitialized = true;
        return;
    }

    float dt = GetFrameTime();

    if (IsKeyPressed(KEY_P)) gamePaused = true;
    if (IsKeyPressed(KEY_R)) gamePaused = false;

    if (!gameOver && !gamePaused) {
        gameTimeRemaining -= dt;
        moveTimer += dt;
        duckMoveTimer += dt;

        if (!levelFailed) {
            MoveWolf(&wolfX, &wolfY, &moveTimer, moveInterval, &lastDirection);
        }

        if (duckMoveTimer >= 1.0f) {
            for (int i = 0; i < NUM_DUCKS; i++) {
                MoveDucks(ducks, NUM_DUCKS, i);
            }
            duckMoveTimer = 0.0f;
        }

        CheckWolfDuckCollision(ducks, NUM_DUCKS, wolfX, wolfY, duckHitSound, &lastDirection);
    }

    int remaining = CountRemainingDucks(ducks, NUM_DUCKS);

    if (!gameOver && (remaining == 0 || gameTimeRemaining <= 0.0f || wolfLives <= 0)) {
        gameOver = true;
        currentLevelScore = NUM_DUCKS - remaining;

        if (remaining == 0) {
            levelCompletedSuccessfully = true;
            levelCompletedFlag = true;
            levelFailed = false;
        } else {
            levelCompletedSuccessfully = false;
            levelCompletedFlag = false;
            levelFailed = true;
        }

        SaveHighScore("highscore.txt", currentLevelScore);
        highScore = LoadHighScore("highscore.txt");

        LeaderboardEntry leaderboard[MAX_LEADERBOARD_ENTRIES];
        LoadLeaderboard(leaderboard);
        int rank = -1;
        UpdateLeaderboard(currentLevelScore, playerName, &rank);

        previousGameState = GAME;
        gameState = MENU;
    }

    if (DrawBackToMenuButton()) {
        savedWolfX = wolfX;
        savedWolfY = wolfY;
        savedLastDirection = lastDirection;
        savedGameTimeRemaining = gameTimeRemaining;
        savedGameOver = gameOver;
        memcpy(savedDucks, ducks, sizeof(ducks));

        resumeRequested = true;
        previousGameState = GAME;
        gameState = MENU;
    }

    UpdateMusicStream(bgMusic);
    if (gamePaused)
        PauseMusicStream(bgMusic);
    else
        ResumeMusicStream(bgMusic);

    if (levelFailed && IsKeyPressed(KEY_R)) {
        wolfLives = MAX_WOLF_LIVES;
        wolfX = initialWolfX;
        wolfY = initialWolfY;
        moveTimer = 0;
        duckMoveTimer = 0;
        gameTimeRemaining = 120.0f;
        gameOver = false;
        levelFailed = false;
        InitDucks(ducks, NUM_DUCKS);
    }
}

void RunGameDraw() {
    int score = NUM_DUCKS - CountRemainingDucks(ducks, NUM_DUCKS);
    DrawUIBar((int)gameTimeRemaining, score, highScore, &gamePaused);
    DrawGrid(currentLevel);
    DrawWolf(wolfTex, wolfX * TILE_SIZE, wolfY * TILE_SIZE, lastDirection);
    DrawDucks(ducks, NUM_DUCKS, duckTex);

    if (gameOver) {
        const char *msg = "GAME OVER! Press R to Restart";
        int fontSize = 30;
        int width = MeasureText(msg, fontSize);
        DrawText(msg, (GetScreenWidth() - width) / 2, GetScreenHeight() / 2, fontSize, RED);
    }
}

void RunGameUnload() {
    UnloadSound(duckHitSound);
    UnloadTexture(duckTex);
    for (int i = 0; i < 4; i++) UnloadTexture(wolfTex[i]);
}

