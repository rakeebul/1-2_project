#include "ducks.h"
#include "grid.h"
#include <bits/stdc++.h>
#include "game.h"
#include "wolf.h"
#include "score.h"

void InitDucks(Duck ducks[], int numDucks) {
    Texture2D duckTexture = LoadTexture("duck.png");
    srand(time(NULL));
    for (int i = 0; i < NUM_DUCKS; ++i) {
        ducks[i].x = rand() % GRID_SIZE;
        ducks[i].y = rand() % GRID_SIZE;
        ducks[i].active = true;
    }
    for (int i = 0; i < numDucks; i++) {
        bool valid = false;
        while (!valid) {
            int x = GetRandomValue(0, GRID_SIZE - 1);
            int y = GetRandomValue(0+topBarHeight, GRID_SIZE - 1+topBarHeight);

            // Check if it's on an obstacle
            if (IsObstacle(currentLevel,x, y)) continue;

            // Check if any other duck is already there
            bool occupied = false;
            for (int j = 0; j < i; j++) {
                if (ducks[j].x == x && ducks[j].y == y) {
                    occupied = true;
                    break;
                }
            }

            if (!occupied) {
                ducks[i].x = x;
                ducks[i].y = y;
                ducks[i].active = true;
                valid = true;
            }
        }
    }
    UnloadTexture(duckTexture);

}
void MoveDucks(Duck ducks[], int numDucks, int currentDuck) {
    int dx[] = {0, 1, 0, -1};  // Right, Down, Left, Up
    int dy[] = {-1, 0, 1, 0};

    int dir = GetRandomValue(0, 3);
    int newX = ducks[currentDuck].x + dx[dir];
    int newY = ducks[currentDuck].y + dy[dir];

    // Bounds check
    if (newX < 0 || newX >= GRID_SIZE || newY < 0+topBarHeight || newY >= GRID_SIZE+topBarHeight) return;

    // Obstacle check
    if (IsObstacle(currentLevel,newX, newY)) return;

    // Overlap check
    for (int i = 0; i < numDucks; i++) {
        if (i != currentDuck && ducks[i].x == newX && ducks[i].y == newY+topBarHeight && ducks[i].active) {
            return;
        }
    }
    ducks[currentDuck].x = newX;
    ducks[currentDuck].y = newY;
}

void CheckWolfDuckCollision(Duck ducks[], int numDucks, int wolfX, int wolfY, Sound hitSound, Direction *lastDirection) {
    for (int i = 0; i < numDucks; i++) {
        if (ducks[i].active) {
            // Check overlap with top or bottom cell of the wolf
            ///partition based on lastDirection
            if((*lastDirection==DOWN || *lastDirection==UP) && ducks[i].x == wolfX &&
                (ducks[i].y == wolfY || ducks[i].y == wolfY + 1)) {
                ducks[i].active = false;
                if (soundEnabled) PlaySound(hitSound);
            }
            if((*lastDirection==LEFT) && ducks[i].y == wolfY &&
                (ducks[i].x == wolfX || ducks[i].x == wolfX)){
                ducks[i].active = false;
                if (soundEnabled) PlaySound(hitSound);
            }
            if((*lastDirection==RIGHT) && ducks[i].y == wolfY &&
                (ducks[i].x == wolfX || ducks[i].x == wolfX + 1)){
                ducks[i].active = false;
                if (soundEnabled) PlaySound(hitSound);
            }
        }
    }
}

void DrawDucks(Duck ducks[], int numDucks, Texture2D duckTex) {
    for (int i = 0; i < numDucks; i++) {
        if (!ducks[i].active) continue;

        if (ducks[i].y >= topBarHeight) {
            DrawTexture(duckTex, ducks[i].x * TILE_SIZE, ducks[i].y * TILE_SIZE, WHITE);
        }
    }
}

int CountRemainingDucks(Duck ducks[], int numDucks) {
    int count = 0;
    for (int i = 0; i < numDucks; i++) {
        if (ducks[i].active) {
            count++;
        }
    }
    return count;
}
