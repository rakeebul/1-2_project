#include <bits/stdc++.h>
#include "score.h"
#include "game.h"

const char *LEADERBOARD_FILE = "leaderboard.txt";

// Load leaderboard from file
void LoadLeaderboard(LeaderboardEntry entries[MAX_LEADERBOARD_ENTRIES]) {
    FILE *file = fopen(LEADERBOARD_FILE, "r");
    if (!file) {
        for (int i = 0; i < MAX_LEADERBOARD_ENTRIES; i++) {
            strcpy(entries[i].name, "---");
            entries[i].score = 0;
        }
        return;
    }

    for (int i = 0; i < MAX_LEADERBOARD_ENTRIES; i++) {
        fscanf(file, "%s %d", entries[i].name, &entries[i].score);
    }

    fclose(file);
}

// Save top leaderboard entries to file
void SaveLeaderboard(const LeaderboardEntry entries[MAX_LEADERBOARD_ENTRIES]) {
    FILE *file = fopen(LEADERBOARD_FILE, "w");
    if (!file) return;

    for (int i = 0; i < MAX_LEADERBOARD_ENTRIES; i++) {
        fprintf(file, "%s %d\n", entries[i].name, entries[i].score);
    }

    fclose(file);
}

// Sort leaderboard in descending order after entrying
void SortLeaderboard(LeaderboardEntry entries[], int count) {
    for (int i = 0; i < count - 1; i++) {
        for (int j = i + 1; j < count; j++) {
            if (entries[j].score > entries[i].score) {
                LeaderboardEntry temp = entries[i];
                entries[i] = entries[j];
                entries[j] = temp;
            }
        }
    }
}

// Update leaderboard if the score qualifies in top 3
bool UpdateLeaderboard(int newScore, const char *name, int *rankPosition) {
    LeaderboardEntry entries[MAX_LEADERBOARD_ENTRIES];
    LoadLeaderboard(entries);

    bool updated = false;

    // newScore updted
    for (int i = 0; i < MAX_LEADERBOARD_ENTRIES; i++) {
        if (newScore > entries[i].score) {
            for (int j = MAX_LEADERBOARD_ENTRIES - 1; j > i; j--) {
                entries[j] = entries[j - 1];
            }
            strncpy(entries[i].name, name, sizeof(entries[i].name) - 1);
            entries[i].name[sizeof(entries[i].name) - 1] = '\0';
            entries[i].score = newScore;
            *rankPosition = i + 1;
            updated = true;
            break;
        }
    }

    if (updated) {
        SortLeaderboard(entries, MAX_LEADERBOARD_ENTRIES);
        SaveLeaderboard(entries);
    }

    return updated;
}

int LoadHighScore(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) return 0;
    int score = 0;
    fscanf(file, "%d", &score);
    fclose(file);
    return score;
}

void SaveHighScore(const char *filename, int newScore) {
    int oldScore = LoadHighScore(filename);
    if (newScore > oldScore) {
        FILE *file = fopen(filename, "w");
        if (file) {
            fprintf(file, "%d\n", newScore);
            fclose(file);
        }
    }
}
