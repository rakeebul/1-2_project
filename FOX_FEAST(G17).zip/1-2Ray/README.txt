1. Download Raylib graphics library and set path variable. 
2. Download raygui.h from GitHub(https://github.com/raysan5/raygui) or just reate a file with this name and copy-paste from (https://github.com/raysan5/raylib/blob/master/examples/shapes/raygui.h).
3. Download quicksand regular (.ttf file) from(https://fonts.google.com/selection) and save it in the same directory with the project file.
4. Create a .cpp project file and add other .cpp and .h file under that.
5. Copy the asset folder where all images, textures, icons, text-font, audio files are kept.
6. Add the asset folder to the same directory with the project file.
7. Build and run