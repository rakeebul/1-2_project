#include "raylib.h"
#define RAYGUI_IMPLEMENTATION
#include "raygui.h"
#include "game.h"
#include "UI_func.h"
#include "score.h"
#include "sound.h"
#include "save_state.h"
#include <stdlib.h>
#include <time.h>

void InitAll() {
    InitWindow(GRID_SIZE * TILE_SIZE, GRID_SIZE * TILE_SIZE + 75, "Fox Feast");
    InitAudioDevice();
    LoadMenuAssets();
    PlayMusicStream(bgMusic);
}

void CloseAll() {
    if (gameInitialized) RunGameUnload();
    UnloadMenuAssets();
    CloseAudioDevice();

    CloseWindow();
}

int main() {
    InitAll();
    SetTargetFPS(60);

    while (!WindowShouldClose()) {
        BeginDrawing();
        ClearBackground(RAYWHITE);

        PlayMusicStream(bgMusic);

        switch (gameState) {
            case MENU:
                showMenu();
                break;

            case MENUfromGame:
                showMenuFromGame();
                break;

            case GAME:
                if (waitingForNameInput && !nameEntered) {
                    ClearBackground(RAYWHITE);
                    DrawText("Enter your name:", 180, 180, 24, BLACK);
                    GuiTextBox((Rectangle){ GetScreenWidth() / 2 - 100, GetScreenHeight() / 2 - 30, 200, 40 }, tempPlayerName, 11, true);

                    if (GuiButton((Rectangle){500, 220, 60, 30}, "OK")) {
                        if (strlen(playerName) == 0) strcpy(playerName, "Player");
                        nameEntered = true;
                        waitingForNameInput = false;
                    }

                    EndDrawing();
                    continue;
                }

                if (!gameInitialized) {
                    RunGameInit();
                    gameInitialized = true;
                }
                RunGameUpdate();
                RunGameDraw();
                break;

            case LEADERBOARD:{
                DrawTexture(leaderboardBG, 0, 0, WHITE);
                const char *title = "Top Scores";
                int titleSize = 40;
                int titleX = (GetScreenWidth() - MeasureText(title, titleSize)) / 2;
                DrawText(title, titleX, 100, titleSize, DARKGREEN);

                LeaderboardEntry leaderboard[MAX_LEADERBOARD_ENTRIES];
                LoadLeaderboard(leaderboard);

                const int fontSize = 20;
                const int startY = 160;    ///common for all in leaderboard
                const int lineSpacing = 40;

                for (int i = 0; i < MAX_LEADERBOARD_ENTRIES; i++) {
                    char line[128];
                    sprintf(line, "%d. %s %d", i + 1, leaderboard[i].name, leaderboard[i].score);

                    int textWidth = MeasureText(line, fontSize);
                    int x = (GetScreenWidth() - textWidth) / 2;
                    int y = startY + i * lineSpacing;

                    DrawText(line, x, y, fontSize, BLACK);
                }
                if (DrawBackToMenuButton()) {
                    showMenu();
                    gameInitialized = false;
                    gameState = MENU;
                }
                break;
            }
                DrawTexture(leaderboardBG, 0 , 0 , WHITE);
                LeaderboardEntry leaderboard[MAX_LEADERBOARD_ENTRIES];
                LoadLeaderboard(leaderboard);
                for (int i = 0; i < MAX_LEADERBOARD_ENTRIES; i++) {
                    DrawText(TextFormat("%d. %s %d", i + 1, leaderboard[i].name, leaderboard[i].score),
                            100, 160 + i * 40, 20, BLACK);
                }
                if (DrawBackToMenuButton()) {
                    showMenu();
                    gameInitialized=false;
                    gameState = MENU;
                }
                break;

            case EXITING:
                EndDrawing();
                CloseAll();
                return 0;
        }
                StopMusicStream(bgMusic);

                EndDrawing();
            }
            StopMusicStream(bgMusic);
            UnloadMusicStream(bgMusic);


    CloseAll();
    return 0;
}
