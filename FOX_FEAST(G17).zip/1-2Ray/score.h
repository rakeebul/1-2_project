#ifndef SCORE_H
#define SCORE_H

#define MAX_LEADERBOARD_ENTRIES 3

struct LeaderboardEntry {
    char name[32];
    int score;
};

void LoadLeaderboard(LeaderboardEntry entries[MAX_LEADERBOARD_ENTRIES]);
void SaveLeaderboard(const LeaderboardEntry entries[MAX_LEADERBOARD_ENTRIES]);

bool UpdateLeaderboard(int newScore, const char *playerName, int *rankPosition);

int LoadHighScore(const char *filename);
void SaveHighScore(const char *filename, int newScore);

#endif


