#ifndef DUCKS_H
#define DUCKS_H
#include "game.h"

void InitDucks(Duck ducks[], int numDucks);
void MoveDucks(Duck ducks[], int numDucks, int index);
void CheckWolfDuckCollision(Duck ducks[], int numDucks, int wolfX, int wolfY, Sound hitSound, Direction *lastDirection);
void DrawDucks(Duck ducks[], int numDucks, Texture2D duckTex);
int CountRemainingDucks(Duck ducks[], int numDucks);

#endif

