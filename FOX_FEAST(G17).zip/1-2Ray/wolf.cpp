#include "wolf.h"
#include "grid.h"
#include "game.h"
#include "score.h"
#include<bits/stdc++.h>

void MoveWolf(int *wolfX, int *wolfY, float *moveTimer, float moveInterval, Direction *lastDirection) {
    if (*moveTimer < moveInterval || levelFailed || wolfLives <= 0)
        return;

    if (wolfLives <= 0) {
        wolfLives = 0;
        levelFailed = true;
    }

    // ---------- UP ----------
    if (IsKeyDown(KEY_UP)) {
        bool blocked = (*wolfY - 1 < topBarHeight) ||
                       IsObstacle(currentLevel, *wolfX, *wolfY - 1);

        if (!blocked) {
            (*wolfY)--;
            *lastDirection = UP;
        } else {
            if (wolfLives > 0) {
                wolfLives--;
                if (wolfLives <= 0) {
                    levelFailed = true;
                }
            }
        }
        *moveTimer = 0;
        return;
    }

    // ---------- DOWN ----------
    if (IsKeyDown(KEY_DOWN)) {
        bool blocked = false;

        if (*lastDirection == RIGHT) {
            blocked = (*wolfX + 1 >= GRID_SIZE) ||
                      (*wolfY + 1 >= GRID_SIZE + topBarHeight) ||
                      IsObstacle(currentLevel, *wolfX + 1, *wolfY + 1);
        } else if (*lastDirection == LEFT) {
            blocked = (*wolfY + 1 < topBarHeight) ||
                      IsObstacle(currentLevel, *wolfX, *wolfY + 1);
        } else {
            blocked = (*wolfY + 2 >= GRID_SIZE + topBarHeight) ||
                      IsObstacle(currentLevel, *wolfX, *wolfY + 2);
        }

        if (!blocked) {
            if (*lastDirection == RIGHT) (*wolfX)++;
            else if (*lastDirection == UP || *lastDirection == DOWN) (*wolfY)++;
            *lastDirection = DOWN;
        } else {
            if (wolfLives > 0) {
                wolfLives--;
                if (wolfLives <= 0) {
                    levelFailed = true;
                }
            }
        }
        *moveTimer = 0;
        return;
    }

    // ---------- LEFT ----------
    if (IsKeyDown(KEY_LEFT)) {
        bool blocked = (*wolfX - 1 < 0) ||
                       IsObstacle(currentLevel, *wolfX - 1, *wolfY);

        if (!blocked) {
            (*wolfX)--;
            *lastDirection = LEFT;
        } else {
            if (wolfLives > 0) {
                wolfLives--;
                if (wolfLives <= 0) {
                    levelFailed = true;
                }
            }
        }
        *moveTimer = 0;
        return;
    }

    // ---------- RIGHT ----------
    if (IsKeyDown(KEY_RIGHT)) {
        bool blocked = (*wolfX + 2 >= GRID_SIZE) ||
                       IsObstacle(currentLevel, *wolfX + 2, *wolfY);

        if (!blocked) {
            (*wolfX)++;
            *lastDirection = RIGHT;
        } else {
            if (wolfLives > 0) {
                wolfLives--;
                if (wolfLives <= 0) {
                    levelFailed = true;
                }
            }
        }
        *moveTimer = 0;
        return;
    }
}

void UnloadWolfTextures(Texture2D wolfTex[4]) {
    for (int i = 0; i < 4; i++) {
        UnloadTexture(wolfTex[i]);
    }
}

bool IsWalkable(int x, int y, int *lastDirection){
    return !IsObstacle(currentLevel,x,y);
}

void DrawWolf(Texture2D wolfTex[4], int x, int y, Direction lastDirection) {
    DrawTexture(wolfTex[lastDirection], x, y, WHITE);
}


