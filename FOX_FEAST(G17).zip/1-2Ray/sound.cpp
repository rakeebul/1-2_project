#include "sound.h"

Music bgMusic;
Sound clickSound;
Sound duckKillSound;
Sound gameOverSound;
Sound gameWinSound;

void InitSounds() {
    InitAudioDevice();

    bgMusic = LoadMusicStream("assets/bgm.mp3");
    clickSound = LoadSound("assets/click.wav");
    duckKillSound = LoadSound("assets/quack.wav");                /// failed attempt to load background music
    gameOverSound = LoadSound("assets/sad.wav");
    gameWinSound = LoadSound("assets/happy.wav");

    PlayMusicStream(bgMusic);
}

void UpdateMusic() {
    UpdateMusicStream(bgMusic);
}

void CloseSounds() {
    UnloadMusicStream(bgMusic);
    UnloadSound(clickSound);
    UnloadSound(duckKillSound);
    UnloadSound(gameOverSound);
    UnloadSound(gameWinSound);
    CloseAudioDevice();
}
