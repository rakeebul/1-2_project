#ifndef GRID_H
#define GRID_H
#include "game.h"
bool IsObstacle(int currentLevel, int x, int y);
void DrawGrid(int currentLevel);
#endif

